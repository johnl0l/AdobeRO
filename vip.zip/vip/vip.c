/*-----------------------------------------------------------------*\
|             ______ ____ _____ ___   __                            |
|            / ____ / _  / ____/  /  /  /                           |
|            \___  /  __/ __/ /  /__/  /___                         |
|           /_____/_ / /____//_____/______/                         |
|                /\  /|   __    __________ _________                |
|               /  \/ |  /  |  /  ___  __/ ___/ _  /                |
|              /      | / ' | _\  \ / / / __//  __/                 |
|             /  /\/| |/_/|_|/____//_/ /____/_/\ \                  |
|            /__/   |_|      npc Script         \/                  |
|                                                                   |
+-------------------------------------------------------------------+
|                     Projeto Ragnarok Online                       |
+-------------------------------------------------------------------+
| - Cria��o: Spell Master 16/07/2011                                |
+-------------------------------------------------------------------+
| - 17/05/2013:                                                     |
                Atualizado para novo source cord rAthena.           |
| - 22/09/2014:                                                     |
|               Atualizado conforme a nova estrutura do banco de    |
|                dados do rAthena.                                  |
| - 04/12/2014:                                                     |
|               Adicionado fun��o de checagem se � verdadeira a     |
|                doa��o na conta do banco.                          |
| - 13/07/2015:                                                     |
|               Adicionado fun��o para manipula��o de GM.           |
| - 15/11/2015:                                                     |
|               Atualizado para compatibilidade com Hercules.       |
| - 08/12/2016:                                                     |
|               Removida fun��es de manipula��o de cash.            |
|               Removida refer�ncias ao Ticket de Vip.              |
|               Removido des�o de GM pois requer manipula��o da     |
|                da source, invi�vel para uso geral.                |
|               Removido consulta para o ADM de verificar se o      |
|                foi feita doa��o na conta do tesoureiro no banco,  |
|                pois requer fun��o php e manipula��o de source se  |
|                tornando ini�vel para o uso geral.                 |
| - 09/12/2016:                                                     |
|               Adicionado vari�veis globais para definir atributos.|
|               Atualizado para compatibilidade com Cronus.         |
\*-----------------------------------------------------------------*/

-	script	#vip_manager	-1,{

	// Configura��o para noobs poderem usar o npc ^.^
	.@Vip_Room$ = "prontera"; // Nome do mapa da sala vip
	.@Vip_X = 150;            // Coordenadas 
	.@Vip_Y = 180;            // Coordenadas

	if(getgroupid() > 0 && getgroupid() < 10) {
		mes "[VIP]";
		mes "Ol� ^FF0000"+strcharinfo(0)+"^000000";
		while(1) {
			next;
			mes "[VIP]";
			mes "O que posso fazer por voc� hoje?";
			next;
			switch(select("Ir para sala vip.:Consultar dias Vip restantes:Nada Obrigado")) {
				case 1:
				mes "[VIP]";
				mes "Volte sempre que precisar de meus servi�os.";
				close2;
				warp .@Vip_Room$,.@Vip_X,.@Vip_Y;
				end;
				case 2:
				query_sql "SELECT DATE_FORMAT(`vip_days`, '%d/%m/%Y') FROM `login` WHERE `account_id`="+getcharid(3),.@VipDays$;
				mes "[VIP]";
				mes "Sua conta Vip � v�lida at� o dia" +.@VipDays$;
				break;
				//case 3: Removida fun��es de consulta de cash
				//case 4: Removida fun��es de compra do ticket de vip
				//case 5: Trasformada em valor 3 para novo menu
				case 3:
				mes "[VIP]";
				mes "Volte sempre que precisar de meus servi�os.";
				close;
			}
		}
	}
	else if(getgroupid() > 9 && getgroupid() < 99) {
		mes "[VIP]";
		mes "Ol� membro da Staff ^FF0000"+strcharinfo(0)+"^000000";
		mes "O que posso fazer por voc� hoje?";
		next;
		switch(select("Ir para sala vip.:Nada Obrigado")) {
			case 1:
			mes "[VIP]";
			mes "Volte sempre que precisar de meus servi�os.";
			close2;
			warp .@Vip_Room$,.@Vip_X,.@Vip_Y;
			end;
			case 2:
			mes "[VIP]";
			mes "Volte sempre que precisar de meus servi�os.";
			close;
		}
	}
	else if(getgroupid() == 99) {
		mes "[VIP]";
		mes "Ol� Administrador ^FF0000"+strcharinfo(0)+"^000000";
		while(1) {
			next;
			mes "[VIP]";
			mes "O que posso fazer por voc� hoje?";
			next;
			switch(select("Verificar Todas Vips:Verificar Conta vip:Adicionar Vip:Remover Vip:Nada Obrigado")) {
				//case 1: Removida checagem da doa��o
				//case 2: Removida manipula��o de gm
				//case 3: Removida manipula��o de cash point
				case 1:
				query_sql "SELECT `account_id`,`userid`,`group_id` FROM `login` WHERE `group_id` = 1",.@AccountId$,.@Userid$,.@GroupId;
				if(!.@GroupId) {
					mes "[VIP]";
					mes "N�o foi encontrada nenhuma conta Vip apartir do ^BB0000group_id 1^000000";
					break;
				}
				mes "======================";
				for (.@i = 0; .@i < getarraysize(.@GroupId); ++.@i) {
					mes "^777777ID:^000000 "+.@AccountId$[.@i];
					mes "^777777Login:^000000 "+.@Userid$[.@i];
					mes "======================";
				}
				break;
				case 2:
				mes "[VIP]";
				mes "Por favor digite o ID ou login para verificar os dias vip na conta";
				next;
				input .@Account$; 
				query_sql "SELECT `account_id` FROM `login` WHERE `userid`='"+.@Account$+"' OR `account_id`='"+.@Account$+"'",.@AccountCheck;
				if (!.@AccountCheck) { 
					mes "[VIP]";
					mes "Conta inexistente.";
					break;
				}
				else {
					query_sql "SELECT DATE_FORMAT(`vip_days`, '%d/%m/%Y') FROM `login` WHERE `account_id`='"+.@Account$+"' OR `userid`='"+.@Account$+"'",.@VipDays$; 
					if (.@VipDays$ == "") {
						mes "[VIP]";
						mes "A conta '^0000FF"+.@Account$+"^000000' n�o possui status Vip.";
						break;
					}
					else {
						mes "[VIP]";
						mes "A conta Vip de '^0000FF"+.@Account$+"^000000' � v�lida at� o dia ^BB0000"+.@VipDays$+"^000000.";
						break;
					}
				}
			case 3:
			mes "[VIP]";
			mes "Por favor digite o ID ou login para adicionar os dias vip na conta";
			next;
			input .@GetAccount$;
			query_sql "SELECT `account_id`,`group_id` FROM `login` WHERE `userid`='"+.@GetAccount$+"' OR `account_id`='"+.@GetAccount$+"'",.@AccountCheck,.@GroupCheck;
			if (!.@AccountCheck) { 
				mes "[VIP]";
				mes "Conta inexistente.";
				break;
			}
			mes "[VIP]";
			mes "Quantos dias vip?";
			next;
			input .@GetVipTime;
			if (.@GroupCheck > 9) {
				mes "[VIP]";
				mes "^FF0000N�o � poss�vel adicionar Vip a conta^000000 "+.@GetAccount$+".";
				mes "^FF0000Porque ela � uma conta Administrativa^000000!";
				break;
			}
			else if (.@GroupCheck == 1) {
				mes "[VIP]";
				mes "Esta conta j� possui status Vip.";
				mes "Deseja almentar mais "+.@GetVipTime+" dias vip a conta?";
				next;
				switch(select("Adicionar VIP:Cancelar")) {
					case 1:
					query_sql "UPDATE `login` SET `group_id` = '1', `vip_days` = DATE_ADD(`vip_days`,INTERVAL "+.@GetVipTime+" DAY) WHERE `group_id` = '1' AND `account_id`='"+.@GetAccount$+"' OR `userid`='"+.@GetAccount$+"'";
					mes "[VIP]";
					mes "Foi adicionado ^FF0000"+.@GetVipTime+"^000000 dias vip na conta ^0000FF"+.@GetAccount$+"^000000.";
					break;
					case 2:
					break;
				}
				break;
			}
			else {
				query_sql "UPDATE `login` SET `group_id` = '1', `vip_days` = DATE_ADD(CURDATE(),INTERVAL "+.@GetVipTime+" DAY) WHERE `group_id` = '0' AND `account_id`='"+.@GetAccount$+"' OR `userid`='"+.@GetAccount$+"'";
				mes "[VIP]";
				mes "Foi adicionado ^FF0000"+.@GetVipTime+"^000000 dias vip na conta ^0000FF"+.@GetAccount$+"^000000.";
				break;
			}
			case 4:
				mes "[VIP]";
				mes "Por favor digite o ID ou login para Remover os dias vip na conta";
				next;
				input .@VipRemove$;
				query_sql "SELECT `account_id`,`group_id` FROM `login` WHERE `userid`='"+.@VipRemove$+"' OR `account_id`='"+.@VipRemove$+"'",.@RemoveCheck,.@VipCheck;
				if (!.@RemoveCheck) { 
					mes "[VIP]";
					mes "Conta inexistente.";
					break;
				}
				if (.@VipCheck > 9) {
					mes "[VIP]";
					mes "^FF0000N�o � poss�vel remover Vip da conta^000000 "+.@VipRemove$+".";
					mes "^FF0000Porque ela � uma conta Administrativa^000000!";
					break;
				}
				else if (.@VipCheck == 1) {
					mes "[VIP]";
					mes "Tem certesa que deseja remover os dias vips da conta "+.@VipRemove$+"?";
					next;
					switch(select("Tenho Sim:Cancelar")) {
						case 1:
						query_sql "UPDATE `login` SET `group_id` = 0, `vip_days` = NULL WHERE `group_id` = '1' AND `account_id`='"+.@VipRemove$+"' OR `userid`='"+.@VipRemove$+"'";
						mes "[VIP]";
						mes "Status Vip removido da conta ^0000FF"+.@VipRemove$+"^000000.";
						mes "Por�m s� ser� v�lido ap�s o jogador deslogar.";
						break;
						case 2:
						break;
					}
					break;
				}
				else {
					mes "[VIP]";
					mes "^FF0000N�o � poss�vel remover Vip da conta^000000 "+.@VipRemove$+".";
					mes "^FF0000Porque ela n�o cont�m status de Vip^000000!";
					break;
				}
			case 5:
			mes "[VIP]";
			mes "Volte sempre que precisar de meus servi�os.";
			close;
			}
		}
	}
	else {
		mes "[VIP]";
		mes "Ol� ^FF0000"+strcharinfo(0)+"^000000";
		mes "Est� perdio?";
		close;
		// Remo��o dos artigos referentes aos dados removidos
	}

}

prontera,160,186,4	duplicate(#vip_manager)	Emis�ria Vip#Evip1	4_F_AGENTKAFRA
morocc,153,81,4	duplicate(#vip_manager)	Emis�ria Vip#Evip2	4_F_AGENTKAFRA
geffen,133,64,4	duplicate(#vip_manager)	Emis�ria Vip#Evip3	4_F_AGENTKAFRA
payon,163,124,4	duplicate(#vip_manager)	Emis�ria Vip#Evip4	4_F_AGENTKAFRA
alberta,104,76,4	duplicate(#vip_manager)	Emis�ria Vip#Evip5	4_F_AGENTKAFRA
izlude,120,96,4	duplicate(#vip_manager)	Emis�ria Vip#Evip6	4_F_AGENTKAFRA
aldebaran,154,111,4	duplicate(#vip_manager)	Emis�ria Vip#Evip7	4_F_AGENTKAFRA
xmas,162,114,4	duplicate(#vip_manager)	Emis�ria Vip#Evip8	4_F_AGENTKAFRA
comodo,226,157,4	duplicate(#vip_manager)	Emis�ria Vip#Evip9	4_F_AGENTKAFRA
yuno,177,189,4	duplicate(#vip_manager)	Emis�ria Vip#Evip10	4_F_AGENTKAFRA
amatsu,190,140,4	duplicate(#vip_manager)	Emis�ria Vip#Evip11	4_F_AGENTKAFRA
gonryun,171,142,4	duplicate(#vip_manager)	Emis�ria Vip#Evip12	4_F_AGENTKAFRA
umbala,101,169,4	duplicate(#vip_manager)	Emis�ria Vip#Evip13	4_F_AGENTKAFRA
louyang,223,120,4	duplicate(#vip_manager)	Emis�ria Vip#Evip14	4_F_AGENTKAFRA
ayothaya,142,103,4	duplicate(#vip_manager)	Emis�ria Vip#Evip15	4_F_AGENTKAFRA
einbroch,84,201,4	duplicate(#vip_manager)	Emis�ria Vip#Evip16	4_F_AGENTKAFRA
lighthalzen,152,110,4	duplicate(#vip_manager)	Emis�ria Vip#Evip17	4_F_AGENTKAFRA
hugel,105,152,4	duplicate(#vip_manager)	Emis�ria Vip#Evip18	4_F_AGENTKAFRA
rachel,165,135,4	duplicate(#vip_manager)	Emis�ria Vip#Evip19	4_F_AGENTKAFRA
veins,221,141,4	duplicate(#vip_manager)	Emis�ria Vip#Evip20	4_F_AGENTKAFRA
moscovia,215,218,4	duplicate(#vip_manager)	Emis�ria Vip#Evip21	4_F_AGENTKAFRA
brasilis,211,162,4	duplicate(#vip_manager)	Emis�ria Vip#Evip22	4_F_AGENTKAFRA

// --------------------------------------------------------------------------------
-	script	GerenciadorVip	-1,{
OnPCLoginEvent:
	if (getgroupid() == 0) {
		query_sql "SELECT (`vip_days` IS NULL OR `vip_days` < CURDATE()) FROM `login` WHERE `account_id` = "+getcharid(3);
		dispbottom "Torne-se um(a) jogador(a) hoje mesmo!";
		end;
	}
	if (getgroupid() == 1) {
		query_sql "UPDATE `login` SET `group_id`= 0 WHERE `group_id` = 1 AND (`vip_days` IS NULL OR `vip_days` < CURDATE())";
		query_sql "SELECT DATE_FORMAT(`vip_days`, '%d/%m/%Y') FROM `login` WHERE `account_id` = "+getcharid(3), @OffVip$;
		dispbottom "Sua conta Vip � v�lida at� o dia "+@OffVip$+"";
		end;
	}
	if (getgroupid() > 9) {
		end;
	}
}