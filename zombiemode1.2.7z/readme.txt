==========================================================================================
----------------------------------------NOTES---------------------------------------------
==========================================================================================

These are modifications that need to be made to files in you "db" folder to make certain
aspects of the mini games work properly and balance gameplay.  Also notes about problems
you may encounter.


====================================skill_db.txt==========================================

445,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_ALCHEMIST,Spirit of the Alchemist
446,9,6,16,0,0x1,0,1,1,yes,0,0xC08,0,none,0,	AM_BERSERKPITCHER,Aid Berserk Potion
447,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_MONK,Spirit of the Monk
448,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_STAR,Spirit of the Star Gladiator
449,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_SAGE,Spirit of the Sage
450,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_CRUSADER,Spirit of the Crusader
451,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_SUPERNOVICE,Spirit of the Supernovice
452,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_KNIGHT,Spirit of the Knight
453,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_WIZARD,Spirit of the Wizard
454,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_PRIEST,Spirit of the Priest
455,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_BARDDANCER,Spirit of the Artist
456,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_ROGUE,Spirit of the Rogue
457,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_ASSASIN,Spirit of the Assasin
458,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_BLACKSMITH,Spirit of the Blacksmith
459,0,6,4,0,0x3,-1,1,1,no,0,0x8,0,weapon,0 ,	BS_ADRENALINE2,Advanced Adrenaline Rush
460,9,6,16,0,0x1,0,5,1,yes,0,0,0,magic,0,	SL_HUNTER,Spirit of the Hunter
461,9,6,16,0,0x1,0,5,1,yes,0,0x200,0,magic,0,	SL_SOULLINKER,Spirit of the Soul Linker


==================================skill_nocast_db.txt=====================================


//Zone 8 - Zombies
426,4096 //Leap
411,4096 //Sprint
362,4096 //Basilica
395,4096 //Sheltering Bliss
87,4096 //Ice Wall
27,4096 //Warp Portal
26,4096 //Teleport

=======================================item_noequip.txt===================================

//Zombie mode - Zone 8
504,512 //White Potion
547,512 //Condensed White Potion
503,512 //Yellow Potion
546,512 //Condensed Yellow Potion
502,512 //Orange Potion
501,512 //Red Potion
545,512 //Condensed Red Potion
506,512 //Green Potion
505,512 //Blue Potion
525,512 //Panacea
601,512 //Fly Wing
602,512 //Butterfly Wing
607,512 //Yggdrasil Berry
608,512 //Yggdrasil Seed
610,512 //Yggdrasil Leaf
522,512 //Mastela Fruit
12118,512 //Fire Resist Potion
12119,512 //Cold Resist Potion
12120,512 //Earth Resist Potion
12121,512 //Thunder Resist Potion
1363,512 //Bloody Axe
12212,512 //Giant Fly Wing

