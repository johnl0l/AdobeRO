CREATE TABLE `pvp` (
  `char_id` int(11) unsigned NOT NULL auto_increment,
  `nick` varchar(255) NOT NULL default '0',
  `vitorias` int(11) unsigned NOT NULL default '0',
  `derrotas` int(11) unsigned NOT NULL default '0',
  KEY `char_id` (`char_id`),
  KEY `vitorias` (`vitorias`),
  KEY `derrotas` (`derrotas`)
) TYPE=MyISAM;

CREATE TABLE `gvg` (
  `guild_id` int(11) unsigned NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL default '0',
  `vitorias` int(11) unsigned NOT NULL default '0',
  `derrotas` int(11) unsigned NOT NULL default '0',
  KEY `guild_id` (`guild_id`),
  KEY `vitorias` (`vitorias`),
  KEY `derrotas` (`derrotas`)
) TYPE=MyISAM;