<? $login = $_POST['login'];
$pass = $_POST['pass'];
$db['server'] = 'localhost';	// < Coloque o IP do seu Banco de Dados [ padr�o: localhost ]
$db['id'] = 'login';             // < Coloque o ID do seu Banco de Dados [ padr�o: ragnarok ]
$db['senha'] = 'senha';          // < Coloque a Senha do seu Banco de Dados [ padr�o: ragnarok ]
$db['db'] = 'ragnarok';             // Coloque o seu banco de dados. [ padr�o: ragnarok ]
$db['cnt'] = mysql_connect ($db['server'], $db['id'], $db['senha']);
$db['cntdb'] = mysql_select_db($db['db']);?>