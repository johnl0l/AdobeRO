<html>
<head>
<title>Ranking GvG - Arena da Morte</title>
</head>
<style>
body, table, tr, td, p, div {
	font:11px Verdana, Arial, Helvetica, sans-serif;
	color:#000000;
	background-color:#F0F5FA;
}
table {background-color:#34498B;}
a:link {text-decoration: none; color: #660066;}
a:visited {text-decoration: none; color: #660066;}
a:hover {text-decoration: underline;}
a:active {text-decoration: none; color: #660066;}
</style>
<body>
<h3>Arena da Morte - Guild vs Guild</h3>
</style>
<table width="100%" cellpadding="4" cellspacing="1">
	<tr>
	<td align="center"><b>Pos.</b></td>
	<td align="left"><b>Cl�</b></td>
	<td align="right"><b>Vit�rias</b></td>
	<td align="right"><b>Derrotas</b></td>
	<td align="center"><b>Pontua��o</b></td></tr>
<?
include('conf.php');
$v1 = @mysql_query("SELECT * FROM `gvg` WHERE vitorias OR derrotas >= 1 ORDER BY `gvg`.`vitorias` DESC LIMIT 50");
$qr  = mysql_query($v1);
$v4 = mysql_num_rows($v1);
$rank = 0;
while($r = mysql_fetch_array($v1)) {
$pontos = $r['vitorias'] - $r['derrotas'];
$rank = $rank+1;
extract($r);
echo '<tr>
	<td align="center">'.$rank.'</td>
	<td align="left">'.$name.'</td>
	<td align="right">'.$vitorias.'</td>
	<td align="right">'.$derrotas.'</td>
	<td align="center">'.$pontos.'</td></tr>';
}
?>
	
</table>
</body>
</html>