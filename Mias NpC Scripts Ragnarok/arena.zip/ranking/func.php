<?
function njob($class) {
	if($class == 0){$class2 = 'Aprendiz';}
	if($class == 1){$class2 = 'Espadachim';}
	if($class == 2){$class2 = 'Mago';}	
	if($class == 3){$class2 = 'Arqueiro';}	
	if($class == 4){$class2 = 'Novi�o';}	
	if($class == 5){$class2 = 'Mercador';}	
	if($class == 6){$class2 = 'Gatuno';}	
	if($class == 7){$class2 = 'Cavaleiro';}	
	if($class == 8){$class2 = 'Sacerdote';}	
	if($class == 9){$class2 = 'Bruxo';}
	if($class == 10){$class2 = 'Ferreiro';}	
	if($class == 11){$class2 = 'Ca�ador';}	
	if($class == 12){$class2 = 'Mercen�rio';}	
	if($class == 13){$class2 = 'Cavaleiro';}	
	if($class == 14){$class2 = 'Templ�rio';}	
	if($class == 15){$class2 = 'Monge';}	
	if($class == 16){$class2 = 'S�bio';}	
	if($class == 17){$class2 = 'Arruaceiro';}	
	if($class == 18){$class2 = 'Alquimista';}	
	if($class == 19){$class2 = 'Bardo';}	
	if($class == 20){$class2 = 'Odalisca';}	
	if($class == 21){$class2 = 'Templ�rio';}	
	if($class == 23){$class2 = 'Super Aprendiz';}
	if($class == 24){$class2 = 'Pistoleiro';}
	if($class == 25){$class2 = 'Ninja';}
	if($class == 4001){$class2 = 'Hiper Aprendiz';}
	if($class == 4002){$class2 = 'Hiper Espadachin';}
	if($class == 4003){$class2 = 'Hiper Mago';}
	if($class == 4004){$class2 = 'Hiper Arqueiro';}
	if($class == 4005){$class2 = 'Hiper Novi�o';}
	if($class == 4006){$class2 = 'Hiper Mercador';}
	if($class == 4007){$class2 = 'Hiper Gatuno';}
	if($class == 4008){$class2 = 'Lorde Cavalheiro';}
	if($class == 4009){$class2 = 'Sumo Sacerdote';}
	if($class == 4010){$class2 = 'Arquimago';}
	if($class == 4011){$class2 = 'Mestre Ferreiro';}
	if($class == 4012){$class2 = 'Atirador de Elite';}
	if($class == 4013){$class2 = 'Algoz';}
	if($class == 4014){$class2 = 'Lorde Cavalheiro(Peco)';}
	if($class == 4015){$class2 = 'Paladino';}
	if($class == 4016){$class2 = 'Mestre';}
	if($class == 4017){$class2 = 'Professor';}
	if($class == 4018){$class2 = 'Desordeiro';}
	if($class == 4019){$class2 = 'Criador';}
	if($class == 4021){$class2 = 'Cigana';}
	if($class == 4020){$class2 = 'Menestrel';}
	if($class == 4022){$class2 = 'Paladino(Peco)';}
	if($class == 4023){$class2 = 'Bebe Aprendiz';}
	if($class == 4024){$class2 = 'Bebe Espadachin';}
	if($class == 4025){$class2 = 'Bebe Mago';}
	if($class == 4026){$class2 = 'Bebe Arqueiro';}
	if($class == 4027){$class2 = 'Bebe Novi�o';}
	if($class == 4028){$class2 = 'Bebe Mercador';}
	if($class == 4029){$class2 = 'Bebe Gatuno';}
	if($class == 4030){$class2 = 'Bebe Cavaleiro';}
	if($class == 4031){$class2 = 'Bebe Sacerdote';}
	if($class == 4032){$class2 = 'Bebe Bruxo';}
	if($class == 4033){$class2 = 'Bebe Ferreiro';}
	if($class == 4034){$class2 = 'Bebe Ca�ador';}			
	if($class == 4035){$class2 = 'Bebe Mercenario';}
	if($class == 4036){$class2 = 'Bebe Cavaleiro(Peco)';}
	if($class == 4037){$class2 = 'Bebe Templario';}
	if($class == 4038){$class2 = 'Bebe Monge';}
	if($class == 4039){$class2 = 'Bebe Sabio';}
	if($class == 4040){$class2 = 'Bebe Arruaceiro';}
	if($class == 4041){$class2 = 'Bebe Alquimista';}
	if($class == 4042){$class2 = 'Bebe Bardo';}
	if($class == 4043){$class2 = 'Bebe Odalisca';}
	if($class == 4044){$class2 = 'Bebe Templario(Peco)';}
	if($class == 4045){$class2 = 'Super Aprendiz Bebe';}
	if($class == 4046){$class2 = 'Taekwon';}
	if($class == 4047){$class2 = 'Gladiador Estelar';}
	if($class == 4048){$class2 = 'Gladiador Estelar';}
	if($class == 4049){$class2 = 'Espiritualista';}
	if($class == 4054){$class2 = 'Cavaleiro R�nico';}
	if($class == 4055){$class2 = 'Arcano';}
	if($class == 4056){$class2 = 'Sentinela';}
	if($class == 4057){$class2 = 'Arcebispo';}
	if($class == 4058){$class2 = 'Mec�nico';}
	if($class == 4059){$class2 = 'Sic�rio';}
	if($class == 4060){$class2 = 'Cavaleiro R�nico T';}
	if($class == 4061){$class2 = 'Arcano T';}
	if($class == 4062){$class2 = 'Sentinela T';}
	if($class == 4063){$class2 = 'Arcebispo T';}
	if($class == 4064){$class2 = 'Mec�nico T';}
	if($class == 4065){$class2 = 'Sic�rio T';}
	if($class == 4066){$class2 = 'Guardi�o Real';}
	if($class == 4067){$class2 = 'Feiticeiro';}
	if($class == 4068){$class2 = 'Trovador';}
	if($class == 4069){$class2 = 'Musa';}
	if($class == 4070){$class2 = 'Shura';}
	if($class == 4071){$class2 = 'Bioqu�mico';}
	if($class == 4072){$class2 = 'Renegado';}
	if($class == 4073){$class2 = 'Guardi�o Real T';}
	if($class == 4074){$class2 = 'Feiticeiro T';}
	if($class == 4075){$class2 = 'Trovador T';}
	if($class == 4076){$class2 = 'Musa T';}
	if($class == 4077){$class2 = 'Shura T';}
	if($class == 4071){$class2 = 'Bioqu�mico T';}
	if($class == 4079){$class2 = 'Renegado T';}
	if($class == 4080){$class2 = 'Cavaleiro R�nico (Drag�o)';}
	if($class == 4081){$class2 = 'Cavaleiro R�nico T (Drag�o)';}
	if($class == 4082){$class2 = 'Guardi�o Real (Grifo)';}
	if($class == 4083){$class2 = 'Guardi�o Real T (Grifo)';}
	if($class == 4084){$class2 = 'Sentinela (Lobo)';}
	if($class == 4085){$class2 = 'Sentinela T (Lobo)';}
	if($class == 4086){$class2 = 'Mec�nico (Rob�)';}
	if($class == 4087){$class2 = 'Mec�nico T (Rob�)';}
return $class2;
}
?>