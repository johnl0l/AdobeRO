<html>
<head>
<title>Ranking PvP - Arena da Morte</title>
</head>
<style>
body, table, tr, td, p, div {
	font:11px Verdana, Arial, Helvetica, sans-serif;
	color:#000000;
	background-color:#F0F5FA;
}
table {background-color:#34498B;}
a:link {text-decoration: none; color: #FC3434;}
a:visited {text-decoration: none; color: #FC3434;}
a:hover {text-decoration: underline;}
a:active {text-decoration: none; color: #FC3434;}
</style>
<body>
<h3>Arena da Morte - Player vs Player</h3>
</style>
<table width="100%" cellpadding="4" cellspacing="1">
	<tr>
	<td align="center"><b>Pos.</b></td>
	<td align="left"><b>Nick</b></td>
	<td align="left"><b>Classe</b></td>
	<td align="right"><b>Vit�rias</b></td>
	<td align="right"><b>Derrotas</b></td>
	<td align="center"><b>Pontua��o</b></td>
	<td align="center"><b>Status</b></td></tr>
<?
include('conf.php');
include('func.php');
$v1 = @mysql_query("SELECT * FROM `pvp` WHERE vitorias OR derrotas >= 1 ORDER BY `pvp`.`vitorias` DESC LIMIT 50");
$v4 = mysql_num_rows($v1);
$rank = 0;
while($r = mysql_fetch_array($v1)) {
$pontos = $r['vitorias'] - $r['derrotas'];
$rank = $rank+1;
extract($r);
$v2 = mysql_query("SELECT * FROM `char` WHERE char_id = $char_id LIMIT 50");	
$v3 = mysql_fetch_array($v2);
@extract($v3);
			if($online == 0){$con = '<font color="red">Offline</font>';}
			if($online == 1){$con = '<font color="green">Online</font>';}	
echo '<tr>
	<td align="center">'.$rank.'</td>
	<td align="left">'.$nick.'</td>
	<td align="left">'.njob($class).'</td>
	<td align="right">'.$vitorias.'</td>
	<td align="right">'.$derrotas.'</td>
	<td align="center">'.$pontos.'</td>
	<td align="center">'.$con.'</td></tr>';
}
?>
	
</table>
</body>
</html>